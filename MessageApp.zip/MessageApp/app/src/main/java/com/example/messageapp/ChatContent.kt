package com.example.messageapp

data class ChatContent(var message: String,var reply: String)

