package com.example.messageapp

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import android.widget.Toast




class DataBaseHandler( var context: Context):SQLiteOpenHelper(context,DATABASE_NAME,null,
    DATABASE_VERSION) {

    companion object {

        const val DATABASE_VERSION = 1
        const val DATABASE_NAME = "message.db"

        //Columns for the Conversation Table
        private const val TABLE_NAME = "conversation"
        private const val USER = "USER_NAME"
        private const val BOT = "Reply_Name"
        private const val ID = "id"

        //Columns for the Messages Table

        const val TABLE_NAME2 = "messages"
        const val ID2 = "Message_ID"
        const val body = "LAST_MESSAGE"
        const val TIMESTAMP = "TIME_STAMP"
        const val STATUS = "CURRENT_STATUS"
        const val CONVERSATION = "CONVERSATION_ID"
        const val NAME="USERNAME"


    }


    override fun onCreate(p0: SQLiteDatabase?) {

        val CREATE_CONVERSATION_TABLE =
            ("CREATE TABLE " + TABLE_NAME + "(" + ID + " INTEGER PRIMARY KEY AUTOINCREMENT," + USER + " TEXT," + BOT + " TEXT" +
                    "" + ")")

        p0?.execSQL(CREATE_CONVERSATION_TABLE)

        val CREATE_MESSAGE_TABLE =
            ("CREATE TABLE " + TABLE_NAME2 +  "(" + ID2 + " INTEGER PRIMARY KEY AUTOINCREMENT," + CONVERSATION + " INTEGER, " + body + " TEXT, " + TIMESTAMP + " TEXT, " + STATUS + " TEXT," + NAME + " TEXT " +
                   "" + ")" )

        p0?.execSQL(CREATE_MESSAGE_TABLE)

    }

    override fun onUpgrade(p0: SQLiteDatabase?, p1: Int, p2: Int) {

//        p0?.execSQL("ALTER TABLE conversation ADD COLUMN Reply_Name TEXT")

        p0!!.execSQL("DROP TABLE IF EXISTS $TABLE_NAME")
        p0!!.execSQL("DROP TABLE IF EXISTS $TABLE_NAME2")
        onCreate(p0)
    }

    fun insertMessage(msg:Message){
        val db=this.writableDatabase
        val contentValues = ContentValues()

        contentValues.put("$CONVERSATION",msg.conversation_id)
        contentValues.put("$NAME",msg.name)
        contentValues.put("$body",msg.message_body)
        contentValues.put("$TIMESTAMP",msg.time_stamp)
        contentValues.put("$STATUS",msg.status)

        val status=db.insert(TABLE_NAME2,null,contentValues)
        db.close()

        if(status==-1.toLong()){


            Toast.makeText(context,"Record  Not Saved in Message Table",Toast.LENGTH_SHORT).show()
        }
        else{
            Toast.makeText(context,"Record  Saved in Message Table",Toast.LENGTH_SHORT).show()
        }

    }
    fun readmessage(id:Int):MutableList<Message>{

        val messageList = mutableListOf<Message>()
        val db = this.readableDatabase
        val sql = "Select m.$CONVERSATION, m.$body, m.$NAME , m.$TIMESTAMP, m.$STATUS from $TABLE_NAME2 as m join $TABLE_NAME as n on n.$ID = m.$CONVERSATION Where m.$CONVERSATION = $id"
        val fetch = db.rawQuery(sql, null)
        while(fetch.moveToNext()){
            val conversationID=fetch.getString(0).toInt()
            val message=fetch.getString(1)
            val name=fetch.getString(2)
            val timestamp=fetch.getString(3)
            val status=fetch.getString(4)


            messageList.add(Message(conversationID,name,message,timestamp,status))

        }
        fetch.close()
        return messageList

    }

    fun insertConversation(std: Conversation) {


        val db = this.writableDatabase
        val contentValues = ContentValues()
        contentValues.put(ID,std.usernum)
        contentValues.put(USER, std.name)
        contentValues.put(BOT, std.reply)
        val status = db.insert(TABLE_NAME, null, contentValues)
        if(status==-1.toLong()){


            Toast.makeText(context,"Record Not Saved in Conversation Table",Toast.LENGTH_SHORT).show()
        }
        else{
            Toast.makeText(context,"Record  Saved in Conversation Table",Toast.LENGTH_SHORT).show()
        }


    }
    fun readConversation(): MutableList<Conversation> {
        val conversationList = mutableListOf<Conversation>()
        val db = this.readableDatabase
        val sql = "Select * from $TABLE_NAME"
        val fetch = db.rawQuery(sql, null)
        while (fetch.moveToNext()) {
            val id=fetch.getString(0).toInt()
            val sendername=fetch.getString(1)
            val recievername=fetch.getString(2)

            conversationList.add(Conversation(id,sendername,recievername))

        }
        fetch.close()
        db.close()

        return conversationList
    }
}


